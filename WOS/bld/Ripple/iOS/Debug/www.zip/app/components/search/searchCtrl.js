﻿'use strict';
angular.module('wos.controllers.search', [])

.controller('SearchCtrl', function ($scope, $ionicPlatform, $cordovaSQLite) {

})